/**
 * Controller de currículos.
 * Gerencia upload, listagem, consulta e exclusão.
 */

const fs = require('fs').promises;
const path = require('path');
const { ResumeRepo } = require('../database/db');
const { extractTextFromPDF, inferCandidateName } = require('../services/pdf.service');
const logger = require('../utils/logger');

/**
 * POST /api/resumes
 * Upload de um currículo PDF.
 */
async function uploadResume(req, res, next) {
  try {
    if (!req.file) {
      return res.status(400).json({ ok: false, error: 'Nenhum arquivo enviado.' });
    }

    const { filename, originalname, path: filePath, size } = req.file;

    logger.info('Processando PDF', { filename, size });

    // Extrai texto do PDF
    let extracted;
    try {
      extracted = await extractTextFromPDF(filePath);
    } catch (extractErr) {
      // Remove arquivo corrompido
      await fs.unlink(filePath).catch(() => {});
      return res.status(422).json({
        ok: false,
        error: extractErr.message || 'Não foi possível extrair texto do PDF.',
      });
    }

    const candidateName = inferCandidateName(extracted.text);

    const resume = ResumeRepo.create({
      filename,
      originalName: originalname,
      candidateName,
      extractedText: extracted.text,
      fileSize: size,
    });

    logger.success('Currículo cadastrado', {
      id: resume.id,
      candidate: candidateName,
      pages: extracted.pages,
    });

    res.status(201).json({
      ok: true,
      data: {
        id: resume.id,
        filename: resume.filename,
        original_name: resume.original_name,
        candidate_name: resume.candidate_name,
        file_size: resume.file_size,
        created_at: resume.created_at,
        pages: extracted.pages,
        text_preview: extracted.text.slice(0, 300),
      },
    });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/resumes
 * Lista todos os currículos com score máximo já obtido.
 */
async function listResumes(req, res, next) {
  try {
    const items = ResumeRepo.findAll();
    res.json({ ok: true, data: items });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/resumes/:id
 * Retorna detalhes de um currículo, incluindo texto.
 */
async function getResume(req, res, next) {
  try {
    const id = parseInt(req.params.id, 10);
    const resume = ResumeRepo.findById(id);
    if (!resume) {
      return res.status(404).json({ ok: false, error: 'Currículo não encontrado.' });
    }
    res.json({ ok: true, data: resume });
  } catch (err) {
    next(err);
  }
}

/**
 * DELETE /api/resumes/:id
 * Remove currículo (banco + arquivo físico).
 */
async function deleteResume(req, res, next) {
  try {
    const id = parseInt(req.params.id, 10);
    const resume = ResumeRepo.findById(id);
    if (!resume) {
      return res.status(404).json({ ok: false, error: 'Currículo não encontrado.' });
    }

    const filePath = path.join(__dirname, '..', 'uploads', resume.filename);
    await fs.unlink(filePath).catch(() => {});
    ResumeRepo.delete(id);

    logger.info('Currículo removido', { id });
    res.json({ ok: true, data: { id } });
  } catch (err) {
    next(err);
  }
}

module.exports = { uploadResume, listResumes, getResume, deleteResume };
