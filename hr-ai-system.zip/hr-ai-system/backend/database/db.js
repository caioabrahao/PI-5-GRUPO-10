/**
 * Camada de banco de dados — SQLite via better-sqlite3 (síncrono, robusto e rápido).
 *
 * Tabelas:
 *   - resumes: currículos enviados (com texto extraído)
 *   - analyses: histórico de análises feitas pela IA
 *   - comparisons: histórico de comparações entre candidatos
 */

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const logger = require('../utils/logger');

const DB_PATH = process.env.DB_PATH
  ? path.resolve(process.env.DB_PATH)
  : path.join(__dirname, 'hr_system.db');

// Garante que o diretório existe
const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new Database(DB_PATH);

// Otimizações de performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ---------------------- SCHEMA ----------------------
db.exec(`
  CREATE TABLE IF NOT EXISTS resumes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    original_name TEXT NOT NULL,
    candidate_name TEXT,
    extracted_text TEXT NOT NULL,
    file_size INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS analyses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    resume_id INTEGER NOT NULL,
    job_description TEXT,
    score INTEGER,
    level TEXT,
    risk TEXT,
    full_analysis TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (resume_id) REFERENCES resumes(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS comparisons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    resume_id_a INTEGER NOT NULL,
    resume_id_b INTEGER NOT NULL,
    job_description TEXT,
    full_comparison TEXT NOT NULL,
    winner TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (resume_id_a) REFERENCES resumes(id) ON DELETE CASCADE,
    FOREIGN KEY (resume_id_b) REFERENCES resumes(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_analyses_resume ON analyses(resume_id);
  CREATE INDEX IF NOT EXISTS idx_analyses_score ON analyses(score DESC);
  CREATE INDEX IF NOT EXISTS idx_resumes_created ON resumes(created_at DESC);
`);

logger.success('Banco de dados SQLite inicializado', { path: DB_PATH });

// ---------------------- HELPERS ----------------------

const ResumeRepo = {
  create({ filename, originalName, candidateName, extractedText, fileSize }) {
    const stmt = db.prepare(`
      INSERT INTO resumes (filename, original_name, candidate_name, extracted_text, file_size)
      VALUES (?, ?, ?, ?, ?)
    `);
    const result = stmt.run(filename, originalName, candidateName, extractedText, fileSize);
    return this.findById(result.lastInsertRowid);
  },

  findById(id) {
    return db.prepare('SELECT * FROM resumes WHERE id = ?').get(id);
  },

  findAll() {
    return db.prepare(`
      SELECT id, filename, original_name, candidate_name, file_size, created_at,
             (SELECT MAX(score) FROM analyses WHERE resume_id = resumes.id) AS best_score
      FROM resumes
      ORDER BY created_at DESC
    `).all();
  },

  delete(id) {
    return db.prepare('DELETE FROM resumes WHERE id = ?').run(id);
  },
};

const AnalysisRepo = {
  create({ resumeId, jobDescription, score, level, risk, fullAnalysis }) {
    const stmt = db.prepare(`
      INSERT INTO analyses (resume_id, job_description, score, level, risk, full_analysis)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const result = stmt.run(
      resumeId,
      jobDescription || null,
      score,
      level,
      risk,
      JSON.stringify(fullAnalysis)
    );
    return this.findById(result.lastInsertRowid);
  },

  findById(id) {
    const row = db.prepare('SELECT * FROM analyses WHERE id = ?').get(id);
    if (row) row.full_analysis = JSON.parse(row.full_analysis);
    return row;
  },

  findByResumeId(resumeId) {
    const rows = db.prepare(
      'SELECT * FROM analyses WHERE resume_id = ? ORDER BY created_at DESC'
    ).all(resumeId);
    return rows.map((r) => ({ ...r, full_analysis: JSON.parse(r.full_analysis) }));
  },

  findRanking(limit = 10) {
    return db.prepare(`
      SELECT a.id AS analysis_id, a.score, a.level, a.risk, a.created_at,
             r.id AS resume_id, r.original_name, r.candidate_name
      FROM analyses a
      JOIN resumes r ON r.id = a.resume_id
      WHERE a.score IS NOT NULL
      ORDER BY a.score DESC, a.created_at DESC
      LIMIT ?
    `).all(limit);
  },

  findHistory(limit = 50) {
    const rows = db.prepare(`
      SELECT a.id, a.resume_id, a.score, a.level, a.risk, a.created_at, a.full_analysis,
             r.original_name, r.candidate_name
      FROM analyses a
      JOIN resumes r ON r.id = a.resume_id
      ORDER BY a.created_at DESC
      LIMIT ?
    `).all(limit);
    return rows.map((r) => ({ ...r, full_analysis: JSON.parse(r.full_analysis) }));
  },
};

const ComparisonRepo = {
  create({ resumeIdA, resumeIdB, jobDescription, fullComparison, winner }) {
    const stmt = db.prepare(`
      INSERT INTO comparisons (resume_id_a, resume_id_b, job_description, full_comparison, winner)
      VALUES (?, ?, ?, ?, ?)
    `);
    const result = stmt.run(
      resumeIdA,
      resumeIdB,
      jobDescription || null,
      JSON.stringify(fullComparison),
      winner
    );
    return this.findById(result.lastInsertRowid);
  },

  findById(id) {
    const row = db.prepare('SELECT * FROM comparisons WHERE id = ?').get(id);
    if (row) row.full_comparison = JSON.parse(row.full_comparison);
    return row;
  },
};

module.exports = { db, ResumeRepo, AnalysisRepo, ComparisonRepo };
