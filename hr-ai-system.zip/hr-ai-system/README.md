# 🤖 HR AI System — Sistema de RH Automatizado com IA

Plataforma web profissional para análise inteligente de currículos usando **OpenAI GPT**. Recrutadores podem fazer upload de currículos em PDF, receber análises detalhadas com IA e comparar candidatos entre si.

---

## ✨ Funcionalidades

- 📄 **Upload de currículos em PDF** (drag & drop)
- 🤖 **Análise profunda com IA**: score detalhado, hard/soft skills, pontos fortes/fracos, risco de contratação, sugestões reais de melhoria
- ⚖️ **Comparação entre candidatos**: 2 candidatos analisados lado a lado, com recomendação final fundamentada
- 📊 **Dashboard moderno** em dark mode com ranking, histórico e filtros
- 🔐 **Segurança**: API keys em variáveis de ambiente, validação de tipo MIME, limite de tamanho

---

## 🧱 Stack

**Backend:** Node.js · Express · SQLite (better-sqlite3) · Multer · pdf-parse · OpenAI SDK
**Frontend:** HTML5 · CSS3 (variáveis CSS, grid, flex) · JavaScript ES6+ puro (sem frameworks)

---

## 📁 Estrutura

```
hr-ai-system/
├── backend/
│   ├── server.js                  # Entry point Express
│   ├── routes/
│   │   ├── resume.routes.js       # Endpoints de currículos
│   │   └── analysis.routes.js     # Endpoints de análise
│   ├── controllers/
│   │   ├── resume.controller.js
│   │   └── analysis.controller.js
│   ├── services/
│   │   ├── openai.service.js      # Integração com OpenAI
│   │   ├── pdf.service.js         # Extração de texto de PDFs
│   │   └── prompts.js             # Prompts profissionais para a IA
│   ├── database/
│   │   └── db.js                  # Setup do SQLite
│   ├── middlewares/
│   │   ├── upload.middleware.js   # Multer + validação
│   │   └── error.middleware.js
│   ├── utils/
│   │   └── logger.js
│   └── uploads/                   # PDFs salvos
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

---

## 🚀 Como rodar

### 1. Pré-requisitos
- Node.js 18+
- Uma API key da OpenAI ([criar aqui](https://platform.openai.com/api-keys))

### 2. Instalação

```bash
# Clone ou baixe este projeto, então:
cd hr-ai-system

# Instale as dependências
npm install

# Crie o arquivo .env baseado no exemplo
cp .env.example .env

# Edite o .env e coloque sua OPENAI_API_KEY
nano .env
```

### 3. Executar

```bash
npm start
# ou em modo dev com hot-reload:
npm run dev
```

Acesse: **http://localhost:3000**

---

## 🧠 Como funciona a análise de IA

O sistema usa prompts especialmente projetados que instruem o GPT a agir como um **recrutador sênior** com 15+ anos de experiência. Para cada currículo, a IA retorna um JSON estruturado contendo:

- **Score (0–100)** — calibrado de forma realista
- **Nível** — Excelente / Bom / Médio / Fraco
- **Compatibilidade com a vaga** — análise textual fundamentada
- **Hard skills detectadas** — array de competências técnicas
- **Soft skills detectadas** — competências comportamentais
- **Experiências relevantes** — resumo das vivências profissionais
- **Pontos fortes** — bem explicados, não genéricos
- **Pontos fracos** — críticos e realistas
- **Sugestões de melhoria** — acionáveis
- **Risco de contratação** — baixo / médio / alto, com justificativa
- **Resumo profissional** — perfil consolidado

---

## 🔐 Segurança

- ✅ API key NUNCA exposta no código — apenas via `process.env`
- ✅ Validação dupla de PDF (extensão + MIME type)
- ✅ Limite de tamanho de arquivo (default 10MB)
- ✅ Sanitização de nomes de arquivo
- ✅ `.env` no `.gitignore` por padrão

---

## 📜 Licença

MIT
