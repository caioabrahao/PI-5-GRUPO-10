/**
 * HR AI System — Frontend
 * Single-file JS modular (sem frameworks), com navegação por views,
 * upload drag&drop, e renderização rica das análises retornadas pela IA.
 */

const API = '/api';

// ============================================================
//                         STATE
// ============================================================
const state = {
  resumes: [],
  currentView: 'upload',
};

// ============================================================
//                         UTILITIES
// ============================================================
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function showLoader(title = 'Processando...', text = 'Isso pode levar alguns segundos') {
  $('#loaderTitle').textContent = title;
  $('#loaderText').textContent = text;
  $('#loader').classList.add('active');
}

function hideLoader() {
  $('#loader').classList.remove('active');
}

function toast(message, type = 'info') {
  const container = $('#toastContainer');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transition = 'opacity 0.3s';
    setTimeout(() => el.remove(), 300);
  }, 4000);
}

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}

function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso.includes('T') ? iso : iso.replace(' ', 'T') + 'Z');
  return d.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
}

function initials(name) {
  if (!name) return '?';
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || '').join('');
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function scoreColor(score) {
  if (score >= 75) return 'var(--success)';
  if (score >= 60) return '#4ade80';
  if (score >= 45) return 'var(--warning)';
  return 'var(--danger)';
}

async function api(path, options = {}) {
  const opts = {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  };
  if (opts.body && typeof opts.body === 'object' && !(opts.body instanceof FormData)) {
    opts.body = JSON.stringify(opts.body);
  }
  if (opts.body instanceof FormData) {
    delete opts.headers['Content-Type'];
  }
  const res = await fetch(`${API}${path}`, opts);
  const data = await res.json().catch(() => ({ ok: false, error: 'Resposta inválida' }));
  if (!res.ok || !data.ok) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  return data.data;
}

// ============================================================
//                       NAVEGAÇÃO
// ============================================================

const VIEW_META = {
  upload:   { title: 'Upload de Currículo', sub: 'Envie um PDF para começar a análise com IA' },
  resumes:  { title: 'Currículos cadastrados', sub: 'Lista de todos os candidatos enviados' },
  analyze:  { title: 'Análise com IA', sub: 'Avaliação detalhada de um candidato individual' },
  compare:  { title: 'Comparação de candidatos', sub: 'Coloque dois candidatos lado a lado' },
  ranking:  { title: 'Ranking', sub: 'Os melhores candidatos com base nas análises feitas' },
  history:  { title: 'Histórico', sub: 'Todas as análises já realizadas' },
};

function switchView(view) {
  state.currentView = view;
  $$('.view').forEach((v) => v.classList.remove('active'));
  $(`#view-${view}`).classList.add('active');

  $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === view));

  const meta = VIEW_META[view];
  if (meta) {
    $('#viewTitle').textContent = meta.title;
    $('#viewSubtitle').textContent = meta.sub;
  }

  // hooks por view
  if (view === 'resumes') loadResumes();
  if (view === 'analyze' || view === 'compare') populateSelects();
  if (view === 'ranking') loadRanking();
  if (view === 'history') loadHistory();
}

$$('.nav-item').forEach((btn) => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});

// ============================================================
//                       HEALTHCHECK
// ============================================================
async function healthcheck() {
  const statusEl = $('#apiStatus');
  try {
    const h = await api('/health');
    statusEl.classList.add('online');
    statusEl.querySelector('.label').textContent = h.openai_configured
      ? `Online · ${h.model}`
      : '⚠ Sem API key';
  } catch {
    statusEl.classList.add('offline');
    statusEl.querySelector('.label').textContent = 'Backend offline';
  }
}

// ============================================================
//                       UPLOAD (drag & drop)
// ============================================================

const dropzone = $('#dropzone');
const fileInput = $('#fileInput');

['dragenter', 'dragover'].forEach((ev) => {
  dropzone.addEventListener(ev, (e) => {
    e.preventDefault();
    e.stopPropagation();
    dropzone.classList.add('dragover');
  });
});

['dragleave', 'drop'].forEach((ev) => {
  dropzone.addEventListener(ev, (e) => {
    e.preventDefault();
    e.stopPropagation();
    dropzone.classList.remove('dragover');
  });
});

dropzone.addEventListener('drop', (e) => {
  const file = e.dataTransfer.files?.[0];
  if (file) handleUpload(file);
});

dropzone.addEventListener('click', () => fileInput.click());
$('#pickFileBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  fileInput.click();
});

fileInput.addEventListener('change', (e) => {
  const file = e.target.files?.[0];
  if (file) handleUpload(file);
  fileInput.value = '';
});

async function handleUpload(file) {
  const statusEl = $('#uploadStatus');
  statusEl.className = 'upload-status hidden';

  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    statusEl.className = 'upload-status error';
    statusEl.textContent = '✗ Apenas arquivos PDF são permitidos.';
    return;
  }

  if (file.size > 10 * 1024 * 1024) {
    statusEl.className = 'upload-status error';
    statusEl.textContent = '✗ Arquivo excede 10MB.';
    return;
  }

  showLoader('Enviando currículo', `Extraindo texto de ${file.name}...`);

  try {
    const fd = new FormData();
    fd.append('resume', file);
    const data = await api('/resumes', { method: 'POST', body: fd });

    statusEl.className = 'upload-status success';
    statusEl.innerHTML = `
      ✓ <strong>${escapeHtml(data.candidate_name || data.original_name)}</strong>
      foi cadastrado (${data.pages} ${data.pages === 1 ? 'página' : 'páginas'}).
      Clique em <a href="#" id="goToAnalyze">Analisar</a> para avaliar com IA.
    `;
    $('#goToAnalyze').addEventListener('click', (e) => {
      e.preventDefault();
      switchView('analyze');
      $('#analyzeResumeSelect').value = data.id;
    });
    toast('Currículo cadastrado com sucesso!', 'success');
    refreshKpis();
  } catch (err) {
    statusEl.className = 'upload-status error';
    statusEl.textContent = `✗ ${err.message}`;
    toast(err.message, 'error');
  } finally {
    hideLoader();
  }
}

// ============================================================
//                       RESUMES LIST
// ============================================================

async function loadResumes() {
  try {
    state.resumes = await api('/resumes');
    renderResumeList();
    refreshKpis();
  } catch (err) {
    toast(err.message, 'error');
  }
}

function renderResumeList() {
  const container = $('#resumeList');
  if (!state.resumes.length) {
    container.innerHTML = '<div class="empty">Nenhum currículo enviado ainda.</div>';
    return;
  }

  container.innerHTML = state.resumes.map((r) => {
    const scoreBadge = r.best_score
      ? `<span class="resume-score" style="background: ${scoreColor(r.best_score)}22; color: ${scoreColor(r.best_score)}">${r.best_score}/100</span>`
      : '<span class="resume-score" style="background:var(--bg-3); color: var(--text-3)">não analisado</span>';

    return `
      <div class="resume-item">
        <div class="resume-icon">${escapeHtml(initials(r.candidate_name || r.original_name))}</div>
        <div class="resume-info">
          <h4>${escapeHtml(r.candidate_name || r.original_name)}</h4>
          <p>${escapeHtml(r.original_name)} · ${formatBytes(r.file_size)} · ${formatDate(r.created_at)}</p>
        </div>
        ${scoreBadge}
        <div class="resume-actions">
          <button class="icon-btn" title="Analisar" data-action="analyze" data-id="${r.id}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
            </svg>
          </button>
          <button class="icon-btn danger" title="Excluir" data-action="delete" data-id="${r.id}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"/>
              <path d="M19 6l-2 14a2 2 0 01-2 2H9a2 2 0 01-2-2L5 6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
            </svg>
          </button>
        </div>
      </div>
    `;
  }).join('');

  container.querySelectorAll('.icon-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const action = btn.dataset.action;
      const id = parseInt(btn.dataset.id, 10);
      if (action === 'analyze') {
        switchView('analyze');
        $('#analyzeResumeSelect').value = id;
      } else if (action === 'delete') {
        deleteResume(id);
      }
    });
  });
}

async function deleteResume(id) {
  if (!confirm('Tem certeza que deseja excluir este currículo? Todas as análises associadas também serão removidas.')) return;
  try {
    await api(`/resumes/${id}`, { method: 'DELETE' });
    toast('Currículo excluído', 'success');
    loadResumes();
  } catch (err) {
    toast(err.message, 'error');
  }
}

$('#refreshResumesBtn').addEventListener('click', loadResumes);

// ============================================================
//                       SELECTS (analyze + compare)
// ============================================================

async function populateSelects() {
  if (!state.resumes.length) {
    await loadResumes();
  }
  const opts = ['<option value="">— escolha um currículo —</option>']
    .concat(state.resumes.map((r) =>
      `<option value="${r.id}">${escapeHtml(r.candidate_name || r.original_name)} · ${escapeHtml(r.original_name)}</option>`
    )).join('');

  ['#analyzeResumeSelect', '#compareResumeA', '#compareResumeB'].forEach((sel) => {
    const el = $(sel);
    const current = el.value;
    el.innerHTML = opts;
    if (current) el.value = current;
  });
}

// ============================================================
//                       ANÁLISE INDIVIDUAL
// ============================================================

$('#runAnalysisBtn').addEventListener('click', async () => {
  const resumeId = $('#analyzeResumeSelect').value;
  const jobDescription = $('#analyzeJobDesc').value.trim();

  if (!resumeId) {
    toast('Selecione um currículo primeiro.', 'error');
    return;
  }

  $('#runAnalysisBtn').disabled = true;
  showLoader('Analisando com IA', 'Nossa IA está avaliando o candidato em profundidade...');

  try {
    const result = await api(`/analysis/${resumeId}`, {
      method: 'POST',
      body: { jobDescription: jobDescription || undefined },
    });
    renderAnalysis(result);
    refreshKpis();
    toast('Análise concluída!', 'success');
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    hideLoader();
    $('#runAnalysisBtn').disabled = false;
  }
});

function renderAnalysis({ resume, analysis }) {
  const container = $('#analysisResult');
  const score = analysis.score || 0;
  const nivel = analysis.nivel || 'Médio';
  const risco = (analysis.risco_contratacao || 'medio').toLowerCase();
  const color = scoreColor(score);
  const circumference = 2 * Math.PI * 65;
  const offset = circumference - (score / 100) * circumference;

  container.innerHTML = `
    <div class="result-grid">
      <!-- ============ COLUNA ESQUERDA: SCORE ============ -->
      <div class="result-score-card level-${nivel}">
        <div class="score-circle">
          <svg viewBox="0 0 150 150">
            <circle class="bg-ring" cx="75" cy="75" r="65"/>
            <circle class="progress-ring"
              cx="75" cy="75" r="65"
              stroke="${color}"
              stroke-dasharray="${circumference}"
              stroke-dashoffset="${circumference}"
              data-target-offset="${offset}"/>
          </svg>
          <div class="score-text">
            <span class="num" style="color:${color}">${score}</span>
            <span class="of">de 100</span>
          </div>
        </div>
        <div class="candidate-name">${escapeHtml(analysis.candidato || resume.candidate_name || resume.original_name)}</div>
        <span class="level-badge ${nivel}">${escapeHtml(nivel)}</span>

        <div class="risk-row">
          <div class="risk-label">Risco de contratação</div>
          <span class="risk-badge ${risco}">${escapeHtml(analysis.risco_contratacao || 'médio')}</span>
          <p class="risk-justify">${escapeHtml(analysis.risco_justificativa || '')}</p>
        </div>
      </div>

      <!-- ============ COLUNA DIREITA: DETALHES ============ -->
      <div class="detail-cards">

        ${analysis.destaque_principal ? `
          <div class="highlight-bar">★ ${escapeHtml(analysis.destaque_principal)}</div>
        ` : ''}

        <div class="detail-card">
          <h4>Resumo profissional</h4>
          <p>${escapeHtml(analysis.resumo_profissional || '')}</p>
        </div>

        <div class="detail-card">
          <h4>Compatibilidade com a vaga</h4>
          <p>${escapeHtml(analysis.compatibilidade_vaga || '')}</p>
        </div>

        ${analysis.hard_skills?.length ? `
          <div class="detail-card">
            <h4>Hard skills detectadas</h4>
            <div class="chips">
              ${analysis.hard_skills.map((s) => `<span class="chip hard">${escapeHtml(s)}</span>`).join('')}
            </div>
          </div>
        ` : ''}

        ${analysis.soft_skills?.length ? `
          <div class="detail-card">
            <h4>Soft skills detectadas</h4>
            <div class="chips">
              ${analysis.soft_skills.map((s) => `<span class="chip soft">${escapeHtml(s)}</span>`).join('')}
            </div>
          </div>
        ` : ''}

        ${analysis.experiencias_relevantes?.length ? `
          <div class="detail-card">
            <h4>Experiências relevantes</h4>
            <div class="item-list">
              ${analysis.experiencias_relevantes.map((exp) => `
                <div class="experience-item">
                  <div class="head">
                    <span class="company">${escapeHtml(exp.empresa || '—')}</span>
                    <span class="period">${escapeHtml(exp.periodo || '')}</span>
                  </div>
                  <div class="role">${escapeHtml(exp.cargo || '')}</div>
                  <div class="relevance">${escapeHtml(exp.relevancia || '')}</div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        ${analysis.pontos_fortes?.length ? `
          <div class="detail-card positive">
            <h4>Pontos fortes</h4>
            <div class="item-list">
              ${analysis.pontos_fortes.map((p) => `
                <div class="item positive">
                  <div class="item-title">✓ ${escapeHtml(p.titulo)}</div>
                  <div class="item-desc">${escapeHtml(p.descricao)}</div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        ${analysis.pontos_fracos?.length ? `
          <div class="detail-card negative">
            <h4>Pontos fracos</h4>
            <div class="item-list">
              ${analysis.pontos_fracos.map((p) => `
                <div class="item negative">
                  <div class="item-title">✗ ${escapeHtml(p.titulo)}</div>
                  <div class="item-desc">${escapeHtml(p.descricao)}</div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        ${analysis.sugestoes_melhoria?.length ? `
          <div class="detail-card">
            <h4>Sugestões de melhoria</h4>
            <div class="item-list">
              ${analysis.sugestoes_melhoria.map((s) => `
                <div class="item info">
                  <div class="item-title">→ ${escapeHtml(s.titulo)}</div>
                  <div class="item-desc">${escapeHtml(s.descricao)}</div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        ${analysis.red_flags?.length ? `
          <div class="detail-card warning">
            <h4>⚠ Red Flags</h4>
            <div class="item-list">
              ${analysis.red_flags.map((r) => `
                <div class="item warning">
                  <div class="item-desc">${escapeHtml(r)}</div>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

      </div>
    </div>
  `;

  // Anima a barra de progresso circular
  setTimeout(() => {
    const ring = container.querySelector('.progress-ring');
    if (ring) ring.style.strokeDashoffset = ring.dataset.targetOffset;
  }, 50);

  container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ============================================================
//                       COMPARAÇÃO
// ============================================================

$('#runCompareBtn').addEventListener('click', async () => {
  const a = $('#compareResumeA').value;
  const b = $('#compareResumeB').value;
  const job = $('#compareJobDesc').value.trim();

  if (!a || !b) { toast('Selecione dois candidatos.', 'error'); return; }
  if (a === b) { toast('Escolha candidatos diferentes.', 'error'); return; }

  $('#runCompareBtn').disabled = true;
  showLoader('Comparando candidatos', 'A IA está colocando os dois lado a lado...');

  try {
    const result = await api('/analysis/compare', {
      method: 'POST',
      body: { resumeIdA: parseInt(a, 10), resumeIdB: parseInt(b, 10), jobDescription: job || undefined },
    });
    renderComparison(result);
    toast('Comparação concluída!', 'success');
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    hideLoader();
    $('#runCompareBtn').disabled = false;
  }
});

function renderComparison({ resumeA, resumeB, comparison }) {
  const container = $('#comparisonResult');
  const c = comparison;
  const winner = c.vencedor; // 'A' ou 'B'

  const cardClass = (side) => `compare-card ${winner === side ? 'winner' : ''}`;

  const renderDiff = (rows = []) => rows.map((d) => `
    <div class="diff-row">
      <div class="aspect">${escapeHtml(d.aspecto || '')}</div>
      <div class="side"><strong>A:</strong> ${escapeHtml(d.candidato_a || '')}</div>
      <div class="side"><strong>B:</strong> ${escapeHtml(d.candidato_b || '')}</div>
      <div class="vantage ${d.vantagem || 'Empate'}">${escapeHtml(d.vantagem || 'Empate')}</div>
    </div>
  `).join('');

  container.innerHTML = `
    <div class="comparison-header">
      <div class="${cardClass('A')}">
        <span class="candidate-label">CANDIDATO A${winner === 'A' ? ' · VENCEDOR' : ''}</span>
        <h3>${escapeHtml(c.candidato_a?.nome || resumeA.name || resumeA.file)}</h3>
        <div class="score-bar" style="margin: 12px auto;">
          <div class="score-bar-track" style="max-width: 180px;">
            <div class="score-bar-fill" style="width: ${c.candidato_a?.score || 0}%; background: ${scoreColor(c.candidato_a?.score || 0)};"></div>
          </div>
          <span class="score-bar-num">${c.candidato_a?.score || 0}</span>
        </div>
        <span class="level-badge ${c.candidato_a?.nivel || 'Médio'}">${escapeHtml(c.candidato_a?.nivel || '')}</span>
        <p class="resumo">${escapeHtml(c.candidato_a?.resumo_curto || '')}</p>
      </div>

      <div class="vs-badge">VS</div>

      <div class="${cardClass('B')}">
        <span class="candidate-label">CANDIDATO B${winner === 'B' ? ' · VENCEDOR' : ''}</span>
        <h3>${escapeHtml(c.candidato_b?.nome || resumeB.name || resumeB.file)}</h3>
        <div class="score-bar" style="margin: 12px auto;">
          <div class="score-bar-track" style="max-width: 180px;">
            <div class="score-bar-fill" style="width: ${c.candidato_b?.score || 0}%; background: ${scoreColor(c.candidato_b?.score || 0)};"></div>
          </div>
          <span class="score-bar-num">${c.candidato_b?.score || 0}</span>
        </div>
        <span class="level-badge ${c.candidato_b?.nivel || 'Médio'}">${escapeHtml(c.candidato_b?.nivel || '')}</span>
        <p class="resumo">${escapeHtml(c.candidato_b?.resumo_curto || '')}</p>
      </div>
    </div>

    <div class="detail-card">
      <h4>Por que ${winner} venceu</h4>
      <p>${escapeHtml(c.vencedor_justificativa || '')}</p>
    </div>

    ${c.diferencas_tecnicas?.length ? `
      <div class="detail-card">
        <h4>Diferenças técnicas</h4>
        <div class="diff-table">${renderDiff(c.diferencas_tecnicas)}</div>
      </div>
    ` : ''}

    ${c.diferencas_experiencia?.length ? `
      <div class="detail-card">
        <h4>Diferenças de experiência</h4>
        <div class="diff-table">${renderDiff(c.diferencas_experiencia)}</div>
      </div>
    ` : ''}

    ${c.potencial_crescimento ? `
      <div class="detail-card positive">
        <h4>Maior potencial de crescimento: Candidato ${escapeHtml(c.potencial_crescimento.maior_potencial || '?')}</h4>
        <p>${escapeHtml(c.potencial_crescimento.justificativa || '')}</p>
      </div>
    ` : ''}

    ${c.risco_contratacao ? `
      <div class="detail-card warning">
        <h4>Mais arriscado: Candidato ${escapeHtml(c.risco_contratacao.mais_arriscado || '?')}</h4>
        <p>${escapeHtml(c.risco_contratacao.justificativa || '')}</p>
      </div>
    ` : ''}

    ${c.recomendacao_final ? `
      <div class="final-rec">
        <h3>🎯 Recomendação final: contratar ${escapeHtml(c.recomendacao_final.contratar || '?')}</h3>
        <div class="argument">"${escapeHtml(c.recomendacao_final.argumento_decisivo || '')}"</div>
        ${c.recomendacao_final.ressalvas?.length ? `
          <div style="margin: 10px 0;">
            <strong style="font-size:13px;">Ressalvas:</strong>
            <ul style="margin-top:6px; padding-left:20px; color: var(--text-2); font-size: 13px;">
              ${c.recomendacao_final.ressalvas.map((r) => `<li>${escapeHtml(r)}</li>`).join('')}
            </ul>
          </div>
        ` : ''}
        <div class="next-steps"><strong>Próximos passos:</strong> ${escapeHtml(c.recomendacao_final.proximos_passos || '')}</div>
      </div>
    ` : ''}
  `;

  container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ============================================================
//                       RANKING
// ============================================================

async function loadRanking() {
  try {
    const rows = await api('/analysis/ranking?limit=20');
    renderRanking(rows);
  } catch (err) {
    toast(err.message, 'error');
  }
}

function renderRanking(rows) {
  const container = $('#rankingList');
  const filter = $('#rankingFilter').value;
  const filtered = filter === 'all' ? rows : rows.filter((r) => r.level === filter);

  if (!filtered.length) {
    container.innerHTML = '<div class="empty">Nenhuma análise no ranking ainda.</div>';
    return;
  }

  container.innerHTML = filtered.map((r, i) => {
    const color = scoreColor(r.score);
    return `
      <div class="rank-item">
        <div class="rank-medal">${i + 1}</div>
        <div>
          <div style="font-weight:600;">${escapeHtml(r.candidate_name || r.original_name)}</div>
          <div style="font-size:12px; color: var(--text-3);">${escapeHtml(r.original_name)} · ${formatDate(r.created_at)}</div>
        </div>
        <div class="score-bar">
          <div class="score-bar-track">
            <div class="score-bar-fill" style="width: ${r.score}%; background: ${color};"></div>
          </div>
          <span class="score-bar-num" style="color: ${color};">${r.score}</span>
        </div>
        <span class="level-badge ${r.level}">${escapeHtml(r.level)}</span>
        <span class="risk-badge ${(r.risk || '').toLowerCase()}">${escapeHtml(r.risk || 'n/a')}</span>
      </div>
    `;
  }).join('');
}

$('#rankingFilter').addEventListener('change', loadRanking);

// ============================================================
//                       HISTÓRICO
// ============================================================

async function loadHistory() {
  try {
    const rows = await api('/analysis/history?limit=50');
    renderHistory(rows);
  } catch (err) {
    toast(err.message, 'error');
  }
}

function renderHistory(rows) {
  const container = $('#historyList');
  if (!rows.length) {
    container.innerHTML = '<div class="empty">Nenhuma análise no histórico.</div>';
    return;
  }
  container.innerHTML = rows.map((r) => {
    const color = scoreColor(r.score);
    return `
      <div class="resume-item" style="grid-template-columns: auto 1fr auto auto;">
        <div class="resume-icon" style="background:${color}22; color:${color};">${escapeHtml(initials(r.candidate_name || r.original_name))}</div>
        <div class="resume-info">
          <h4>${escapeHtml(r.candidate_name || r.original_name)}</h4>
          <p>${formatDate(r.created_at)} · ${escapeHtml(r.full_analysis?.destaque_principal || '')}</p>
        </div>
        <span class="resume-score" style="background:${color}22; color:${color}">${r.score}/100</span>
        <span class="level-badge ${r.level}">${escapeHtml(r.level)}</span>
      </div>
    `;
  }).join('');
}

// ============================================================
//                       KPIs / BADGES
// ============================================================

async function refreshKpis() {
  try {
    const resumes = await api('/resumes');
    state.resumes = resumes;
    const history = await api('/analysis/history?limit=100').catch(() => []);
    $('#resumeCount').textContent = resumes.length;
    $('#kpiTotal').textContent = resumes.length;
    $('#kpiAnalyses').textContent = history.length;
  } catch {
    // silencioso — não bloqueia
  }
}

// ============================================================
//                       INIT
// ============================================================

(async function init() {
  await healthcheck();
  await refreshKpis();
  switchView('upload');
})();
